voice_list = [
    {"Name": "zh-CN-XiaoxiaoNeural","Gender": "Female","Chinese":"晓晓-女性",},

    {"Name": "zh-CN-XiaoyiNeural","Gender": "Female","Chinese":"小易-女性"},

    {"Name": "zh-CN-YunjianNeural", "Gender": "Male","Chinese":"云锦-男性"},

    {"Name": "zh-CN-YunxiNeural", "Gender": "Male","Chinese":"云溪-男性"},

    {"Name": "zh-CN-YunxiaNeural", "Gender": "Male","Chinese":"云霞-男性"},

    {"Name": "zh-CN-YunyangNeural", "Gender": "Male","Chinese":"云阳-男性"},

    {"Name": "zh-CN-liaoning-XiaobeiNeural", "Gender": "Female","Chinese":"小贝-女性-辽宁"},

    {"Name": "zh-CN-shaanxi-XiaoniNeural", "Gender": "Female","Chinese":"小妮-女性-山西"},

    {"Name": "zh-HK-HiuGaaiNeural", "Gender": "Female","Chinese":"胡志明-女性-香港"},

    {"Name": "zh-HK-HiuMaanNeural", " Gender": "Female","Chinese":"胡玛纳-女性-香港"},

    {"Name": "zh-HK-WanLungNeural", "Gender": "Male","Chinese":"王路-男性-香港"},

    {"Name": "zh-TW-HsiaoChenNeural", "Gender": "Female","Chinese":"哈克-女性-台湾"},

    {"Name": "zh-TW-HsiaoYuNeural", "Gender": "Female","Chinese":"哈克-女性-台湾"},

    {"Name": "zh-TW-YunJheNeural", "Gender": "Male","Chinese":"哈克-男性-台湾"}
]
